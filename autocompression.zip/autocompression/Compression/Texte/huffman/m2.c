#include<stdlib.h>
#include<stdio.h>
#include"huffman.h"

int main(int argc, char *argv[])
{
	whole_decomp(argv[1]);
}
